<?php

    if (!function_exists('globalImageURL')) 
    { 
         function globalImageURL()
        {
            
            return 'assets/img/';
        }
    }


    if (!function_exists('siteLogo')) 
    { 
        function siteLogo() 
        { 
            return 'assets/img/icons/logo.svg';
        } 
    }


    if (!function_exists('imageExtensions')) 
    { 
        function imageExtensions() 
        { 
            return ['jpg', 'jpeg', 'png', 'gif', 'bmp','svg'];
        } 
    }

    if (!function_exists('servicesShowLimit')) 
    { 
        function servicesShowLimit() 
        { 
            return 6;
        } 
    }

    if (!function_exists('featuredServicesShowLimit')) 
    { 
        function featuredServicesShowLimit() 
        { 
            return 4;
        } 
    }

    if (!function_exists('storeImage')) 
    {
        /**
         * Store image in specified folder with validation
         * 
         * @param UploadedFile $imageFile - The uploaded image file
         * @param string $folderName - Folder name (e.g., 'abouts', 'banners', 'services')
         * @param string $imageName - Desired image name without extension (e.g., 'image1')
         * 
         * @return string - Path relative to storage/app/public (e.g., 'abouts/image1.jpg')
         * @throws \Exception - If image extension is invalid
         */
        function storeImage($imageFile, $folderName, $imageName)
        {
            if (!$imageFile) {
                throw new \Exception('No image file provided');
            }

            // Get the file extension
            $extension = strtolower($imageFile->getClientOriginalExtension());

            // Validate extension
            if (!in_array($extension, imageExtensions())) {
                throw new \Exception('Invalid image extension. Allowed extensions: ' . implode(', ', imageExtensions()));
            }

            // Create folder path
            $folderPath = 'public/' . $folderName;

            // Store the image
            $fileName = $imageName . '.' . $extension;
            $imageFile->storeAs($folderPath, $fileName);

            // Return the relative path for database storage
            return $folderName . '/' . $fileName;
        }


    }