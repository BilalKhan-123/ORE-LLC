 <!-- About Section -->
            <section id="about" class="about section">

                <!-- Section Title -->
                <div class="container section-title" data-aos="fade-up">
                    <h2><?php echo e(__('messages.about_us')); ?><br></h2>
                    <p><?php echo e(__('messages.tag_about')); ?></p>
                </div><!-- End Section Title -->

                <div class="container">
                    <div class="row gy-4">
                        <div class="col-lg-6 position-relative align-self-start" data-aos="fade-up" data-aos-delay="100">
                            <?php if($data['about']->main_image): ?>
                                
                                <img src="<?php echo e(asset($data['about']->main_image)); ?>" class="img-fluid" alt="About Image">
                            <?php else: ?>
                                <img src="assets/img/about.jpg" class="img-fluid" alt="">
                            <?php endif; ?>
                            <?php if($data['about']->video_url): ?>
                                <a href="<?php echo e($data['about']->video_url); ?>" class="glightbox pulsating-play-btn"></a>
                            <?php endif; ?>
                        </div>
                        <div class="col-lg-6 content" data-aos="fade-up" data-aos-delay="200">
                            <h3><?php echo e($data['about']->title ?? 'About Our Organization'); ?></h3>
                            <p class="fst-italic py-3">
                            <?php echo e($data['about']->sub_title ?? 'Discover what makes us unique'); ?>

                            </p>
                           <?php if(!empty($data['about']->description)): ?>
                                <?php
                                    $description = $data['about']->first()->description;
                                    $wordCount = str_word_count(strip_tags($description));
                                    $preview = \Illuminate\Support\Str::words(strip_tags($description), 100, '...');
                                ?>

                                <div class="about-description">
                                    <?php echo nl2br(e($preview)); ?>

                                </div>

                                <?php if($wordCount > 100): ?>
                                    <a href="<?php echo e(route('site.about')); ?>" class="btn-read-more text-success">
                                        <?php echo e(__('messages.read_more')); ?>

                                    </a>
                                <?php endif; ?>
                            <?php endif; ?>



                        </div>
                    </div>

                </div>

            </section>
            <!-- /About Section --><?php /**PATH /var/www/html/resources/views/site/about.blade.php ENDPATH**/ ?>