 <!-- Hero Section -->
            <section id="hero" class="hero section">

                <div id="hero-carousel" class="carousel slide carousel-fade" data-bs-ride="carousel" data-bs-interval="5000">
                    <?php if($data['banners']->isEmpty() || $data['banners']->count() > 0): ?>   
                        <?php $__currentLoopData = $data['banners']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="carousel-item <?php echo e($key == 0 ? 'active' : ''); ?>">
                            <?php if($banner->main_image): ?>
                                
                                <img src="<?php echo e(asset($banner->main_image)); ?>" alt="Banner Image" class="d-block w-100">
                            <?php else: ?>
                                <img src="assets/img/hero-carousel/hero-carousel-<?php echo e($key + 1); ?>.jpg" alt="<?php echo e($banner->title ?? 'Banner Image'); ?>" class="d-block w-100">
                            <?php endif; ?>
                            <div class="container">
                                <h2><?php echo e($banner->title ?? 'Welcome to Medicio'); ?></h2>
                                <p><?php echo e($banner->description ?? 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.'); ?></p>
                                <a href="<?php echo e(route('site.about')); ?>" class="btn-get-started"><?php echo e(__('messages.about')); ?></a>
                            </div>
                        </div><!-- End Carousel Item -->
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    
                    <a class="carousel-control-prev" href="#hero-carousel" role="button" data-bs-slide="prev">
                    <span class="carousel-control-prev-icon bi bi-chevron-left" aria-hidden="true"></span>
                    </a>

                    <a class="carousel-control-next" href="#hero-carousel" role="button" data-bs-slide="next">
                    <span class="carousel-control-next-icon bi bi-chevron-right" aria-hidden="true"></span>
                    </a>

                    <ol class="carousel-indicators"></ol>

                </div>

            </section>
            <!-- /Hero Section --><?php /**PATH /var/www/html/resources/views/site/banner.blade.php ENDPATH**/ ?>