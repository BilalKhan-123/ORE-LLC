<section id="faq" class="faq section light-background">

                <!-- Section Title -->
                <div class="container section-title" data-aos="fade-up">
                    <h2><?php echo e(__('messages.faq')); ?></h2>
                    <p><?php echo e(__('messages.tag_faq')); ?></p>
                </div><!-- End Section Title -->

                <div class="container">

                    <div class="row justify-content-center">

                    <div class="col-lg-10" data-aos="fade-up" data-aos-delay="100">

                        <div class="faq-container">

                        <?php $__empty_1 = true; $__currentLoopData = $data['faqs']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="faq-item">
                            <h3><?php echo e($faq->question); ?></h3>
                            <div class="faq-content">
                            <p><?php echo e($faq->short_answer ?? ''); ?></p>
                            </div>
                            <i class="faq-toggle bi bi-chevron-right"></i>
                        </div><!-- End Faq item-->
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="faq-item">
                            <p class="text-center text-muted">No FAQs available at the moment.</p>
                        </div>
                        <?php endif; ?>

                        </div>

                    </div><!-- End Faq Column-->

                    </div>

                </div>

            </section><?php /**PATH /var/www/html/resources/views/site/faq.blade.php ENDPATH**/ ?>