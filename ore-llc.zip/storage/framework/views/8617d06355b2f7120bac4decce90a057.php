 <!-- Bootstrap Bundle JS -->
        

  <script src="<?php echo e(asset('assets/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?> "></script>
  <script src="<?php echo e(asset('assets/vendor/php-email-form/validate.js')); ?> "></script>
  <script src="<?php echo e(asset('assets/vendor/aos/aos.js')); ?> "></script>
  <script src="<?php echo e(asset('assets/vendor/glightbox/js/glightbox.min.js')); ?> "></script>
  <script src="<?php echo e(asset('assets/vendor/purecounter/purecounter_vanilla.js')); ?> "></script>
  <script src="<?php echo e(asset('assets/vendor/swiper/swiper-bundle.min.js')); ?> "></script>

  <!-- Main JS File -->
  <script src="<?php echo e(asset('assets/js/main.js')); ?> "></script><?php /**PATH /var/www/html/resources/views/includes/footer-links.blade.php ENDPATH**/ ?>