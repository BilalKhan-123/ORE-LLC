<footer id="footer" class="footer light-background">

    <div class="container footer-top">
        <div class="row gy-4">
            <div class="col-lg-4 col-md-6 footer-about">
            <a href="#about" class="logo d-flex align-items-center">
                <span class="sitename"><?php echo e(config('site.siteTitle')); ?></span>
            </a>
            <div class="footer-contact pt-3">
                <p><?php echo e($data['contacts']->address ?? ''); ?></p>
                
                <?php
                    $phones = [];

                    if (!empty($data['contacts']->phone_1)) {
                        $phones[] = $data['contacts']->phone_1;
                    }
                    if (!empty($data['contacts']->phone_2)) {
                        $phones[] = $data['contacts']->phone_2;
                    }
                    if (!empty($data['contacts']->phone_3)) {
                        $phones[] = $data['contacts']->phone_3;
                    }
                ?>
                <?php
                    $emails = [];

                    if (!empty($data['contacts']->email_1)) {
                        $emails[] = $data['contacts']->email_1;
                    }
                    if (!empty($data['contacts']->email_2)) {
                        $emails[] = $data['contacts']->email_2;
                    }
                    if (!empty($data['contacts']->email_3)) {
                        $emails[] = $data['contacts']->email_3;
                    }
                ?>
                <p class="mt-3"><strong><?php echo e(__('messages.phone')); ?>:</strong> <span><?php echo e(!empty($phones) ? implode(' | ', $phones) : __('messages.phone_number')); ?></span></p>
                <p><strong><?php echo e(__('messages.email')); ?>:</strong> <span><?php echo e(!empty($emails) ? implode(' | ', $emails) : __('messages.email_address')); ?></span></p>
            </div>
            
            <div class="social-links d-flex mt-4">
                <a href=""><i class="bi bi-twitter-x"></i></a>
                <a href=""><i class="bi bi-facebook"></i></a>
                <a href=""><i class="bi bi-instagram"></i></a>
                <a href=""><i class="bi bi-linkedin"></i></a>
            </div>
            </div>

            <div class="col-lg-2 col-md-3 footer-links">
            <h4><?php echo e(__('messages.usefull_links')); ?></h4>
            <ul>
                <li><a href="<?php echo e(route('home')); ?>"><?php echo e(__('messages.home')); ?></a></li>
                <li><a href="<?php echo e(route('site.about')); ?>"><?php echo e(__('messages.about')); ?></a></li>
                <li><a href="<?php echo e(route('site.services')); ?>"><?php echo e(__('messages.services')); ?></a></li>
                <li><a href="<?php echo e(route('site.departments')); ?>"><?php echo e(__('messages.departments')); ?></a></li>
                <li><a href="<?php echo e(route('site.contact')); ?>"><?php echo e(__('messages.contact')); ?></a></li>
                
            </ul>
            </div>

            <div class="col-lg-2 col-md-3 footer-links">
            <h4><?php echo e(__('messages.our_services')); ?></h4>
            <ul>
                <?php if(!empty($data['services']) && $data['services']->count() > 0): ?>
                    <?php $__currentLoopData = $data['services']->slice(0, 5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="<?php echo e(route('site.services.details',$service->slug)); ?>"><?php echo e($service->title); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <li><a href="#"><?php echo e(__('messages.no_services')); ?></a></li>
                <?php endif; ?>
            </ul>

            </div>

            <div class="col-lg-2 col-md-3 footer-links">
            <h4><?php echo e(__('messages.our_departments')); ?></h4>
            <ul> 
                <?php if($data['departments']->count() > 0): ?>
                    <?php $__currentLoopData = $data['departments']->slice(0, 5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="#"><?php echo e($department->title); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <li><a href="#"><?php echo e(__('messages.no_departments')); ?></a></li>
                <?php endif; ?>
            </ul>
             
            </div>

        </div>
    </div>

    <div class="container copyright text-center mt-4">
        <p>© <span><?php echo e(__('messages.copyright')); ?> <?php echo e(date('Y')); ?></span> <strong class="px-1 sitename"><?php echo e(config('site.siteTitle')); ?></strong> <span><?php echo e(__('messages.all_rights_reserved')); ?></span></p>
        <div class="credits">
            <?php echo e(__('messages.designed_by')); ?> <a href="https://www.linkedin.com/in/bilal-khan-bk1992/">Bilal</a> | <a href="https://www.linkedin.com/in/bilal-khan-bk1992/">Khan</a>
        </div>
    </div>

</footer><?php /**PATH /var/www/html/resources/views/includes/site-footer.blade.php ENDPATH**/ ?>