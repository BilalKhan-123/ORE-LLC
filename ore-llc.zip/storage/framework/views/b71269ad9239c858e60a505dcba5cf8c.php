 <section id="testimonials" class="testimonials section">

                <!-- Section Title -->
                <div class="container section-title" data-aos="fade-up">
                    <h2>Testimonials</h2>
                    <p>What our clients are saying about us</p>
                </div><!-- End Section Title -->

                <div class="container" data-aos="fade-up" data-aos-delay="100">

                    <div class="swiper init-swiper" data-speed="600" data-delay="5000" data-breakpoints="{ &quot;320&quot;: { &quot;slidesPerView&quot;: 1, &quot;spaceBetween&quot;: 40 }, &quot;1200&quot;: { &quot;slidesPerView&quot;: 3, &quot;spaceBetween&quot;: 40 } }">
                    <script type="application/json" class="swiper-config">
                        {
                        "loop": true,
                        "speed": 600,
                        "autoplay": {
                            "delay": 5000
                        },
                        "slidesPerView": "auto",
                        "pagination": {
                            "el": ".swiper-pagination",
                            "type": "bullets",
                            "clickable": true
                        },
                        "breakpoints": {
                            "320": {
                            "slidesPerView": 1,
                            "spaceBetween": 40
                            },
                            "1200": {
                            "slidesPerView": 3,
                            "spaceBetween": 20
                            }
                        }
                        }
                    </script>
                    <div class="swiper-wrapper">

                        <?php $__empty_1 = true; $__currentLoopData = $data['testimonials']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimonial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="swiper-slide">
                        <div class="testimonial-item">
                        <p>
                        <i class="bi bi-quote quote-icon-left"></i>
                            <span><?php echo e($testimonial->comment); ?></span>
                            <i class="bi bi-quote quote-icon-right"></i>
                            </p>
                            <?php if($testimonial->image): ?>
                                <img src="<?php echo e(asset('storage/' . $testimonial->image)); ?>" class="testimonial-img" alt="<?php echo e($testimonial->name); ?>">
                            <?php else: ?>
                                <img src="assets/img/testimonials/testimonials-1.jpg" class="testimonial-img" alt="<?php echo e($testimonial->name); ?>">
                            <?php endif; ?>
                            <h3><?php echo e($testimonial->name); ?></h3>
                            <h4><?php echo e($testimonial->position ?? 'Client'); ?></h4>
                        </div>
                        </div><!-- End testimonial item -->
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="swiper-slide">
                        <div class="testimonial-item">
                            <p class="text-center text-muted">No testimonials available at the moment.</p>
                        </div>
                        </div>
                        <?php endif; ?>

                    </div>
                    <div class="swiper-pagination"></div>
                    </div>

                </div>

            </section><?php /**PATH /var/www/html/resources/views/site/testimonials.blade.php ENDPATH**/ ?>