 <!-- Featured Services Section -->
            <section id="featured-services" class="featured-services section">

                 <!-- Section Title -->
                    <div class="container section-title" data-aos="fade-up">
                        <h2><?php echo e(__('messages.featured_services')); ?></h2>
                        <p><?php echo e(__('messages.tag_featured_services')); ?></p>
                    </div>
                <!-- End Section Title -->
                <div class="container">

                    <div class="row gy-4">
                        <?php
                            $services = $data['services']->take(featuredServicesShowLimit());
                        ?>
                        
                        <?php $__empty_1 = true; $__currentLoopData = $data['services']->where('is_featured', 1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="col-xl-3 col-md-6 d-flex" data-aos="fade-up" data-aos-delay="<?php echo e(($key % 4) * 100 + 100); ?>">
                                <a href="<?php echo e(route('site.services.details', $service->slug)); ?>" class="stretched-link">
                                    <div class="service-item position-relative">
                                        <div class="icon">
                                            <img src="<?php echo e(asset($service->logo)); ?>" 
                                                alt="<?php echo e($service->title); ?>" 
                                                width="80" height="60" 
                                                class="rounded" 
                                                style="object-fit: cover;">
                                        </div>
                                        <h4><?php echo e($service->title); ?></h4>
                                        <p class="stretched-link"><?php echo e(Str::limit($service->sub_title, 100)); ?></p>
                                    </div>
                                </a>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div class="col-12 text-center">
                                <p><?php echo e(__('messages.no_services')); ?></p>
                            </div>
                        <?php endif; ?>

                        <?php if($data['services']->where('is_featured', 1)->count() > featuredServicesShowLimit()): ?>
                            <div class="col-12 text-center mt-4">
                                <a href="<?php echo e(route('site.services.featured')); ?>" class="btn-read-more text-success">
                                    <?php echo e(__('messages.featured_services') ?? 'Featured Services'); ?>

                                </a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

            </section>
            <!-- /Featured Services Section -->

            <section id="services" class="services section">

                <!-- Section Title -->
                <div class="container section-title" data-aos="fade-up">
                    <h2><?php echo e(__('messages.services')); ?></h2>
                    <p><?php echo e(__('messages.tag_services')); ?></p>
                </div>
                <!-- End Section Title -->

                <div class="container">

                    <div class="row gy-4">
                        <?php
                            $services = $data['services']->take(servicesShowLimit());
                        ?>

                        <?php $__empty_1 = true; $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="<?php echo e(($key % 3) * 100 + 100); ?>">
                                <div class="service-item position-relative">
                                    <div class="icon" style="border-radius: 50px; overflow: hidden;">
                                        <img src="<?php echo e(asset($service->logo)); ?>" 
                                            alt="<?php echo e($service->title); ?>" 
                                            width="80" height="60" 
                                            class="rounded" 
                                            style="object-fit: cover;">
                                    </div>
                                    <a href="<?php echo e(route('site.services.details', $service->slug)); ?>" class="stretched-link">
                                        <h3><?php echo e($service->title); ?></h3>
                                        <?php if($service->is_featured): ?> <small class="badge bg-success rounded-pill""><?php echo e(__('messages.featured')); ?></small><?php endif; ?>
                                    </a>
                                    <p><?php echo e(Str::limit($service->sub_title, 250)); ?></p>
                                </div>
                            </div><!-- End Service Item -->
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div class="col-12 text-center">
                                <p><?php echo e(__('messages.no_services')); ?></p>
                            </div>
                        <?php endif; ?>

                        
                        <?php if($data['services']->count() > servicesShowLimit()): ?>
                            <div class="col-12 text-center mt-4">
                                <a href="<?php echo e(route('site.services')); ?>" class="btn-read-more text-success">
                                    <?php echo e(__('messages.all_services') ?? 'All Services'); ?>

                                </a>
                            </div>
                        <?php endif; ?>

                    </div>
                </div>

            </section><?php /**PATH /var/www/html/resources/views/site/services.blade.php ENDPATH**/ ?>