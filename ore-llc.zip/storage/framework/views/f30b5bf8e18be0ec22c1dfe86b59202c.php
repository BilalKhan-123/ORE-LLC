<section id="departments" class="tabs section">

                <!-- Section Title -->
                <div class="container section-title" data-aos="fade-up">
                    <h2><?php echo e(__('messages.departments')); ?></h2>
                    <p><?php echo e(__('messages.tag_departments')); ?></p>
                </div><!-- End Section Title -->

                <div class="container" data-aos="fade-up" data-aos-delay="100">

                    <div class="row">
                    <div class="col-lg-3">
                        <ul class="nav nav-tabs flex-column">
                        <?php $__empty_1 = true; $__currentLoopData = $data['departments']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <li class="nav-item">
                            <a class="nav-link <?php echo e($key == 0 ? 'active show' : ''); ?>" data-bs-toggle="tab" href="#tabs-tab-<?php echo e($key + 1); ?>"><?php echo e($department->title); ?></a>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <li class="nav-item">
                            <span class="text-muted"><?php echo e(__('messages.no_departments')); ?></span>
                        </li>
                        <?php endif; ?>
                        </ul>
                    </div>
                    <div class="col-lg-9 mt-4 mt-lg-0">
                        <div class="tab-content">
                        <?php $__empty_1 = true; $__currentLoopData = $data['departments']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="tab-pane <?php echo e($key == 0 ? 'active show' : ''); ?>" id="tabs-tab-<?php echo e($key + 1); ?>">
                            <div class="row">
                            <div class="col-lg-8 details order-2 order-lg-1">
                                <h3><?php echo e($department->title); ?></h3>
                                <p class="fst-italic"><?php echo e($department->sub_title ?? 'Professional department'); ?></p>
                                
                            </div>
                            <div class="col-lg-4 text-center order-1 order-lg-2">
                                <?php if($department->main_image): ?>
                                    <img src="<?php echo e(asset($department->main_image)); ?>" alt="<?php echo e($department->title); ?>" class="img-fluid">
                                <?php else: ?>
                                    <img src="assets/img/departments-<?php echo e($key + 1); ?>.jpg" alt="<?php echo e($department->title); ?>" class="img-fluid">
                                <?php endif; ?>
                            </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="tab-pane active show">
                            <p class="text-left text-muted"><?php echo e(__('messages.no_departments')); ?></p>
                        </div>
                        <?php endif; ?>
                        </div>
                    </div>
                    </div>

                </div>

            </section><?php /**PATH /var/www/html/resources/views/site/departments.blade.php ENDPATH**/ ?>