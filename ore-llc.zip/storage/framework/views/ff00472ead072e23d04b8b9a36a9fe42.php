<section id="gallery" class="gallery section">

                <!-- Section Title -->
                <div class="container section-title" data-aos="fade-up">
                    <h2><?php echo e(__('messages.gallery')); ?><br></h2>
                    <p><?php echo e(__('messages.tag_gallery')); ?></p>
                </div><!-- End Section Title -->

                <div class="container" data-aos="fade-up" data-aos-delay="100">
                    <style>
                        .gallery-img {
                            width: 100%;          /* fill container width */
                            height: 200px;        /* fixed height (adjust as needed) */
                            object-fit: cover;    /* crop to fit without distortion */
                            border-radius: 6px;   /* optional styling */
                        }

                    </style>
                    <div class="swiper init-swiper">
                    <script type="application/json" class="swiper-config">
                        {
                        "loop": true,
                        "speed": 600,
                        "autoplay": {
                            "delay": 5000
                        },
                        "slidesPerView": "auto",
                        "centeredSlides": true,
                        "pagination": {
                            "el": ".swiper-pagination",
                            "type": "bullets",
                            "clickable": true
                        },
                        "breakpoints": {
                            "320": {
                            "slidesPerView": 1,
                            "spaceBetween": 0
                            },
                            "768": {
                            "slidesPerView": 3,
                            "spaceBetween": 20
                            },
                            "1200": {
                            "slidesPerView": 5,
                            "spaceBetween": 20
                            }
                        }
                        }
                    </script>
                    <div class="swiper-wrapper align-items-center">
                        
                        <?php if($data['galleries']->isEmpty() || $data['galleries']->count() > 0): ?>   
                            <?php $__currentLoopData = $data['galleries']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="swiper-slide">
                                    <a class="glightbox" data-gallery="images-gallery" href="<?php echo e(asset($gallery->main_image)); ?>">
                                        <img src="<?php echo e(asset($gallery->main_image)); ?>" 
                                            class="gallery-img" 
                                            alt="<?php echo e($gallery->title ?? 'Gallery Image'); ?>">
                                    </a>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <div class="swiper-slide">
                                <span class="text-muted">No gallery images available.</span>    
                        <?php endif; ?>
                    </div>
                    <div class="swiper-pagination"></div>
                    </div>

                </div>

            </section><?php /**PATH /var/www/html/resources/views/site/gallery.blade.php ENDPATH**/ ?>