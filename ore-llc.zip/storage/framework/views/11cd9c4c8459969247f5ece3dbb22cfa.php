<header id="header" class="header sticky-top">

    <div class="topbar d-flex align-items-center">
        <div class="container d-flex justify-content-center justify-content-md-between">
            <div class="d-none d-md-flex align-items-center">
                <i class="bi bi-clock me-1"></i> <?php echo e(__('messages.monday_hours')); ?>

            </div>
            <?php
                $phones = [];

                if (!empty($data['contacts']->phone_1)) {
                    $phones[] = $data['contacts']->phone_1;
                }
                if (!empty($data['contacts']->phone_2)) {
                    $phones[] = $data['contacts']->phone_2;
                }
                if (!empty($data['contacts']->phone_3)) {
                    $phones[] = $data['contacts']->phone_3;
                }
            ?>

            <div class="d-flex align-items-center">
            <i class="bi bi-phone me-1"></i> <?php echo e(__('messages.call_us')); ?> <?php echo e(!empty($phones) ? implode(' | ', $phones) : __('messages.phone_number')); ?>


            </div>
            <div class="d-flex align-items-center ms-3 px-5">
                <div class="dropdown">
                   
                    
                    <?php if(auth()->guard()->check()): ?>
                        <form action="<?php echo e(route('admin.logout')); ?>" method="POST" class="d-inline">
                            <?php echo csrf_field(); ?>
                            <button class="btn btn-sm btn-outline-danger">
                                <i class="bi bi-box-arrow-right"></i> Logout
                            </button>
                        </form>
                         <a target="__BLANK" href="<?php echo e(route('admin.dashboard')); ?>" class="btn btn-sm btn-outline-info">
                            <i class="bi bi-person-circle"></i> Dashboard
                        </a>
                    <?php else: ?>
                         <button class="btn btn-sm btn-outline-info dropdown-toggle" type="button" id="langDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                            <?php echo e(strtoupper(app()->getLocale())); ?>

                        </button>
                        <ul class="dropdown-menu" aria-labelledby="langDropdown">
                            <li><a class="dropdown-item" href="<?php echo e(route('lang.switch', 'en')); ?>">English</a></li>
                            <li><a class="dropdown-item" href="<?php echo e(route('lang.switch', 'de')); ?>">Deutsch</a></li>
                        </ul>
                        <a href="<?php echo e(route('admin.login')); ?>" class="btn btn-sm btn-outline-info">
                            <i class="bi bi-person-circle"></i> <?php echo e(__('messages.admin_login')); ?>

                        </a>
                    <?php endif; ?>


                </div>
            </div>
        </div>
    </div><!-- End Top Bar -->

    <div class="branding d-flex align-items-center">
        <div class="container position-relative d-flex align-items-center justify-content-end">
            <a href="<?php echo e(url('/')); ?>" class="logo d-flex align-items-center me-auto">
            <img style="height: 100px" src="<?php echo e(asset(siteLogo())); ?>" alt="">
            <!-- Uncomment the line below if you also wish to use a text logo -->
            <!-- <h1 class="sitename">Medicio</h1>  -->
            </a>

            <nav id="navmenu" class="navmenu">
            <ul>
                <li><a href="<?php echo e(route('home')); ?>" class="active"><?php echo e(__('messages.home')); ?></a></li>
                <li><a href="<?php echo e(route('site.about')); ?>"><?php echo e(__('messages.about')); ?></a></li>
                <li><a href="<?php echo e(route('site.services')); ?>"><?php echo e(__('messages.services')); ?></a></li>
                <li><a href="<?php echo e(route('site.departments')); ?>"><?php echo e(__('messages.departments')); ?></a></li>
                
                <li><a href="<?php echo e(route('site.contact')); ?>"><?php echo e(__('messages.contact')); ?></a></li>
            </ul>
            <i class="mobile-nav-toggle d-xl-none bi bi-list"></i>
            </nav>
        </div>
    </div>

</header><?php /**PATH /var/www/html/resources/views/includes/site-header.blade.php ENDPATH**/ ?>